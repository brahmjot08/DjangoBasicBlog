(function(a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))
})(navigator.userAgent || navigator.vendor || window.opera);

var stemyinterval = 0;
mypassvar = 0;

devicewidth = screen.width;
	var myprevslide=999,myprevindex=999,globalactivepage=0,oldtime=0;
	mycheckboxcount = 0;
	gallerywidth =  $(document).width();
	galleryheight =  $(document).height();
	$(".gallerydtls").css('width',gallerywidth - 100);
	$(".gallerydtls").css('height',galleryheight - 100);
	$(".GalleryImg img").css('max-height',gallerywidth - 400);
	$(".GalleryImg img").css('max-width','100%');
        $(document).ready(function () {
			VideoList = [
    "videos/Patient_Awareness_Video_English.mp4",
    "videos/Patient_Awareness_Video_Hindi.mp4",
    "videos/Patient_Awareness_Video_Kannada.mp4",
    "videos/Patient_Awareness_Video_Tamil.mp4",
    "videos/Patient_Awareness_Video_Telugu.mp4",
	"videos/Patient_Awareness_Video_Bengali.mp4" ];
			
		mysymvar = 1;			
			
			fn_hideall();
	
	function fn_hideall(){
		$("#slide11Cont").hide();
		$("#slide12Cont").hide();
		$("#slide13Cont").hide();
		$("#slide14Cont").hide();
		$("#slide21Cont").hide();
		$("#slide31Cont").hide();
		$("#slide32Cont").hide();
		$("#slide41Cont").hide();
		$("#slide42Cont").hide();
		$("#slide421Cont").hide();
		$("#slide43Cont").hide();
		$("#slide44Cont").hide();
		$("#slide51Cont").hide();
		$("#slide52Cont").hide();
		$("#slide53Cont").hide();
		$("#slide54Cont").hide();
		$("#slide55Cont").hide();
		$("#slide56Cont").hide();
	}

		
$('#MenuBarLnks ul ul li:odd').addClass('odd');
$('#MenuBarLnks ul ul li:even').addClass('even');
$('#MenuBarLnks > ul > li > a').click(function() {
  $('#MenuBarLnks li').removeClass('active');
  $(this).closest('li').addClass('active');	
  var checkElement = $(this).next();
  if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
    $(this).closest('li').removeClass('active');
    checkElement.slideUp('normal');
  }
  if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
    $('#MenuBarLnks ul ul:visible').slideUp('normal');
    checkElement.slideDown('normal');
  }
  if($(this).closest('li').find('ul').children().length == 0) {
    return true;
  } else {
    return false;	
  }		
});			
		t2 = new TimelineLite();
		t3 = new TimelineLite();
		t4 = new TimelineLite();
		t41 = new TimelineLite();
		t5 = new TimelineLite();
		t421 = new TimelineLite();
		t6 = new TimelineLite();
		t7 = new TimelineLite();
		t8 = new TimelineLite();
		t9 = new TimelineLite();
		t10 = new TimelineLite();
		t11 = new TimelineLite();
		t12 = new TimelineLite();
		t13 = new TimelineLite();
		t71 = new TimelineLite();
		t2n = new TimelineLite();
		t3n = new TimelineLite();
		t4n = new TimelineLite();
		t41n = new TimelineLite();
		t5n = new TimelineLite();
		t6n = new TimelineLite();
		t7n = new TimelineLite();
		t8n = new TimelineLite();
		t9n = new TimelineLite();
		t10n = new TimelineLite();
		t11n = new TimelineLite();
		t12n = new TimelineLite();
		t13n = new TimelineLite();
		menu = new TimelineLite();
		slide11 = new TimelineLite();
			
		screenheight = $(window).height();	
		maindivheight = screenheight - 240;
		
		$("#GalleryImages").css('height',screenheight);
		$("#GalleryVideos").css('height',screenheight);
		$("#GalleryNews").css('height',screenheight);
		
		$("#GalleryImages .main").css('height',maindivheight);
		$("#GalleryVideos .main").css('height',maindivheight);
		$("#GalleryNews .main").css('height',maindivheight);
	
		nextstatus1 = $(".nextloader1 span");
		nextstatus2 = $(".nextloader2 span");
		nextstatus3 = $(".nextloader3 span");
		nextstatus4 = $(".nextloader4 span");
		nextstatus8 = $(".nextloader8 span");
		
		socialshare = $(".social_share");
		sociallinks = $(".social_links");
		
		$("body").css('display','block');
        
		var clickedelement = 0;
		
		
        devicewidth = screen.width;

        breakintroloop = 0;
        
		myslideindex1 = 0;
		
		myindexarray = "";
        myindex = 0;
		
		/*$('.ChkBox').click(function() {
			if ($(this).prop('checked')==true){ 
				mycheckboxcount += 1;
			}else{
				mycheckboxcount -= 1;
			}
		});*/
		
		$('#getCheckboxesButton').click(function() {
			checkboxValues = [];
			
			$('input[type="checkbox"]:checked').each(function(index, elem) {
				checkboxValues.push($(elem).val());
			});
			
			if(checkboxValues.length == 0){
				alert("Fill out the following questionnaire");
			}else{
			   //alert(checkboxValues.join(','));
			   $('#SelfAsstCont').css("display","none");
			   $('#SelfAsstResult').css("display","block");

				
				
				for(i = 0; i < checkboxValues.length; i++){
					//$("#yourUL").append("<li>" + $("#yourinputtextbox").val() + "</li>");
					$('.txtAge').append("<li>" + checkboxValues[i] + "</li>");
				}
				 $('#symres_scrollbar').tinyscrollbar();
				
			}
    	});

		$('.mysubmit').click(function() {
			$('#SelfAsstCont').css("display","none");
			$('#SelfAsstResult').css("display","block");
			$('.txtAge').html("<p>You have selected "+mycheckboxcount+" checkbox of symptoms. You could be at risk of thyroid. Request you to consult your doctor.</p>")
		});
		mynewvar =0;
		var surl = window.location.href;
		surl = surl.substring(surl.lastIndexOf("/") + 1, surl.length).toLowerCase();
		
        $('#fullpage').fullpage({
            anchors: ['Intro','WhatIsThyroid', 'Symptoms', 'Causes', 'Prevalence', 'Pregnancy', 'Diagnosis', 'Gallery', 'News', 'Faqs'],
            slidesNavigation: true,
			scrollingSpeed: 1200,
			easing: 'easeInSine',
            afterLoad: function(anchorLink, index) {
				
			//alert(index);
			mycurrentindex = index;
			globalactivepage = index;
			
			if(globalactivepage ==8)
			{
				activeframe="gallery";
			}
			else if(globalactivepage ==9)
			{
				activeframe="news";
			}
				console.log(anchorLink+':'+ index)
	            history.pushState(null, null, anchorLink);
				if(index == 1){
					//alert(1);
					$("#VideoBg").css('display', 'none');
					mypassvar = 1;
					setTimeout(function(){ 
					  if(mypassvar == 0){
						  TweenLite.to(IntroDiv, 0, {opacity: 0});
						  $("#ScrollDiv").css('display', 'block');
					  }else{
						  TweenLite.to(IntroDiv, 1, {opacity: 1});
						  $("#ScrollDiv").css('display', 'block');
						  $("#ScrollDiv").css("bottom",90);
						  mypassvar = 0;
					  }
					 }, 100);
						 TweenLite.to(IntroDiv, 1, {opacity: 1});
						 $("#ScrollDiv").css("display","block");
						$("#ScrollDiv").css("bottom",0);
						$("#ScrollTxt").html("Scroll down to What is Thyroid Disorder");
						repeatTimeline();
					
				}
				if(index == 2){
					$("#slide11Cont").show();
				   $("#slide12Cont").show();
				   $("#slide13Cont").show();
				   $("#slide14Cont").show();
				   Fn_Slide11();
				   Fn_Slide14();
				   video_src2.play();
				   MouseTrueFPage();
				   $("#ScrollDiv").css("bottom",0);
				}
				if(index == 3){
					$("#ScrollDiv").css("display","none");
				    $("#ScrollTxt").html("Scroll down to Causes");	
					$("#slide21Cont").show();
					fn_symptomsmain();
					$("#ScrollDiv").css("bottom",0);
				}
				if(index == 4){
					$("#slide31Cont").show();
				   $("#slide32Cont").show();
				   Fn_Slide31();
					Fn_Slide32();
					MouseTrueFPage();
					$("#ScrollDiv").css("bottom",0);
				}
				if(index == 5){
				   $("#slide41Cont").show();
				   $("#slide42Cont").show();
				   $("#slide421Cont").show();
				   $("#slide43Cont").show();
				   $("#slide44Cont").show();
				   Fn_Slide41();
					Fn_Slide42();
					Fn_Slide421();
					Fn_Slide43();
					Fn_Slide44();
					MouseTrueFPage();	
					$("#ScrollDiv").css("bottom",0);
				}
				if(index == 6){
				   $("#slide51Cont").show();
				   $("#slide52Cont").show();
				   $("#slide53Cont").show();
				   $("#slide54Cont").show();
				   $("#slide55Cont").show();
				   $("#slide56Cont").show();
				   Fn_Slide51();
					Fn_Slide52();
					Fn_Slide53();
					Fn_Slide54();
					Fn_Slide55();
					Fn_Slide56();
					MouseTrueFPage();
					$("#ScrollDiv").css("bottom",0);
				}
				if (index == 7){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","block");
					$("#ScrollTxt").html("Scroll down to Videos &amp; Gallery");
					MouseTrueFPage();
					Fn_Slide71();
					$("#ScrollDiv").css("bottom",0);
				}
				if (index == 8){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","block");
					$("#ScrollTxt").html("Scroll down to News &amp; Views");
					MouseTrueFPage();
					$("#ScrollDiv").css("bottom",0);
				}
				if (index == 9){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","block");
					$("#ScrollTxt").html("Scroll down to FAQs");
					MouseTrueFPage();
					$("#ScrollDiv").css("bottom",0);
				}

				
            },
            afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {
                var loadedSlide = $(this);
				var d = new Date();
    			var n = d.getTime();
				
				if(n-oldtime < 2000){
					buggyload = true;
				}else{
					buggyload = false;
				}
				
				//alert(index);
				//console.log("newtime="+n);
				//console.log("oldtime="+oldtime);
				//console.log("time diff="+ (n-oldtime));
			//console.log("index="+index);
			//console.log("prev index="+myprevindex);
            //console.log("slideIndex="+slideIndex);
			//console.log("prev slide="+myprevslide);				
				oldtime = n;
			
			
				if(myprevslide==slideIndex && buggyload) return false;
				if(index == 2){
					$("#ScrollDiv").css("display","block");
				    $("#ScrollTxt").html("Scroll down to Symptoms");
					$("#skiptoframe").html("Skip to Causes");
					var myindexarray1 = ["test1", "test2", "test3", "test4"];
				   myindex = index;
				   myslideindex1 = slideIndex;
				   myindexarray = myindexarray1;
				   mypassvar = 1;
				   
				   $(".controlArrow.prev .myrolltext").fadeOut('fast');
				   $(".controlArrow.next .myrolltext").fadeOut('fast');
				   
				   if(slideIndex == 0){
					   TweenLite.to(nextstatus1, 1, {width:25+"%"});
					   fn_hideall();
					   $("#slide11Cont").show();
					   history.pushState(null, null, anchorLink);
					   Fn_Slide11();
				   }else if(slideIndex == 1){
					   TweenLite.to(nextstatus1, 1, {width:50+"%"})
					   fn_hideall();
					   $("#slide12Cont").show();
					   
				   }else if(slideIndex == 2){
					   TweenLite.to(nextstatus1, 1, {width:75+"%"})
					   fn_hideall();
					   $("#slide13Cont").show();
				   }else if(slideIndex == 3){
					   TweenLite.to(nextstatus1, 1, {width:100+"%"})
					   fn_hideall();
					   $("#slide14Cont").show();
					   Fn_Slide14();
				   }
				}
				
				if(index == 4){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","block");
				   $("#ScrollTxt").html("Scroll down to Prevalence");
				    $("#skiptoframe").html("Skip to Thyroid");
					$("#ScrollDiv").css("display","block");
				   $("#ScrollTxt").html("Scroll down to Prevalence");
					var myindexarray1 = ["test5", "test6"];
				   myindex = index;
				   myslideindex1 = slideIndex;
				   myindexarray = myindexarray1;
				   $(".controlArrow.prev .myrolltext").fadeOut('fast');
				   $(".controlArrow.next .myrolltext").fadeOut('fast');
				   if(slideIndex == 0){

					   TweenLite.to(nextstatus2, 1, {width:50+"%"})
					   fn_hideall();
					   $("#slide31Cont").show();
					   history.pushState(null, null, anchorLink);
				   		Fn_Slide32();
				   }else if(slideIndex == 1){
					   TweenLite.to(nextstatus2, 1, {width:100+"%"})
					   fn_hideall();
					  $("#slide32Cont").show();
				   		Fn_Slide31();
				   
				   }
				   
				}
				if(index == 5){
					
					$("#VideoBg").css('display', 'none');
					 $("#ScrollDiv").css("display","block");
				   $("#ScrollTxt").html("Scroll down to Pregnancy");
					var myindexarray1 = ["test7", "test8s", "test9", "test10", "test11"];
				   myindex = index;
				   myslideindex1 = slideIndex;
				   myindexarray = myindexarray1;
				   $(".controlArrow.prev .myrolltext").fadeOut('fast');
				   $(".controlArrow.next .myrolltext").fadeOut('fast');
				   if(slideIndex == 0){console.log('Prevalence');
					   TweenLite.to(nextstatus3, 1, {width:20+"%"})
					   fn_hideall();
					   $("#slide41Cont").show();
					  Fn_Slide41();
					  history.pushState(null, null, anchorLink);
				   }else if(slideIndex == 1){
					   TweenLite.to(nextstatus3, 1, {width:40+"%"})
					   fn_hideall();
					   $("#slide42Cont").show();
					   Fn_Slide42();
					
				   }else if(slideIndex == 2){					   
					   TweenLite.to(nextstatus3, 1, {width:60+"%"})
					   fn_hideall();
					   $("#slide421Cont").show();
					   Fn_Slide421();
					
				   }else if(slideIndex == 3){
					   TweenLite.to(nextstatus3, 1, {width:80+"%"})
					   fn_hideall();
					   $("#slide43Cont").show();
					   Fn_Slide43();
					
				   }else if(slideIndex == 4){
					   TweenLite.to(nextstatus3, 1, {width:100+"%"})
					   fn_hideall();
					   $("#slide44Cont").show();
					   Fn_Slide44();
				   }
				  
				}
				if(index == 6){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","block");
				   $("#ScrollTxt").html("Scroll down to Diagnosis &amp; Treatment");
					var myindexarray1 = ["test12", "test13", "test14", "test15", "test16", "test17"];
				   myindex = index;
				   myslideindex1 = slideIndex;
				   myindexarray = myindexarray1;
				   $(".controlArrow.prev .myrolltext").fadeOut('fast');
				   $(".controlArrow.next .myrolltext").fadeOut('fast');
				   if(slideIndex == 0){
					   TweenLite.to(nextstatus4, 1, {width:16.6+"%"})
					   fn_hideall();
					   $("#slide51Cont").show();
					   history.pushState(null, null, anchorLink);
					   Fn_Slide51();
				   }else if(slideIndex == 1){
					   TweenLite.to(nextstatus4, 1, {width:33.2+"%"})
					   fn_hideall();
					   $("#slide52Cont").show();
					   Fn_Slide52();
				   }else if(slideIndex == 2){					   
					   TweenLite.to(nextstatus4, 1, {width:49.8+"%"})
					   fn_hideall();
					   $("#slide53Cont").show();
					  Fn_Slide53();
				   }else if(slideIndex == 3){
					   TweenLite.to(nextstatus4, 1, {width:66.4+"%"})
					   fn_hideall();
					   $("#slide54Cont").show();
					   Fn_Slide54();
				   }else if(slideIndex == 4){
					   TweenLite.to(nextstatus4, 1, {width:83+"%"})
					   fn_hideall();
					   $("#slide55Cont").show();
					  Fn_Slide55();
				   }else if(slideIndex == 5){
					   TweenLite.to(nextstatus4, 1, {width:100+"%"})
					   fn_hideall();
					   $("#slide56Cont").show();
					  Fn_Slide56();
				   }
				} 
				if(index == 10){
					$("#VideoBg").css('display', 'none');
					$("#ScrollDiv").css("display","none");	
					var myindexarray1 = ["test18", "test19", "test20", "test21","test22"];
				   myindex = index;
				   myslideindex1 = slideIndex;
				   myindexarray = myindexarray1;
				   $(".controlArrow.prev .myrolltext").fadeOut('fast');
				   $(".controlArrow.next .myrolltext").fadeOut('fast');
				   if(slideIndex == 0){
					   TweenLite.to(nextstatus8, 1, {width:20+"%"})
					   history.pushState(null, null, anchorLink);
				   }else if(slideIndex == 1){
					   TweenLite.to(nextstatus8, 1, {width:40+"%"})
				   }else if(slideIndex == 2){					   
					   TweenLite.to(nextstatus8, 1, {width:60+"%"})
				   }else if(slideIndex == 3){
					   TweenLite.to(nextstatus8, 1, {width:80+"%"})
				   }else if(slideIndex == 4){
					   TweenLite.to(nextstatus8, 1, {width:100+"%"})
				   }
				  			   
				}
				
				myprevslide = slideIndex;
				
            },
			onLeave: function(index) {
				myprevindex = index;
			},
			
			
        });
		
MouseFalseFPage();
		$('#discrollbar').tinyscrollbar();
		$('#pdfscrollbar').tinyscrollbar();
		
		$(".controlArrow.prev").hover(
		function(){
			myarrayslength = myindexarray.length;
			if(myslideindex1 == 0){
				myrollovertextpre = myindexarray[myarrayslength -1];
			}else{
				myrollovertextpre = myindexarray[myslideindex1 - 1];
			}
			$(".controlArrow.prev .myrolltext").text(myrollovertextpre);
			$(".controlArrow.prev .myrolltext").fadeIn('slow');
		},
		function(){
			$(".controlArrow.prev .myrolltext").text(myrollovertextpre);
			$(".controlArrow.prev .myrolltext").fadeOut('fast');
		}
     );
	 
$(".controlArrow.next").hover(
    function(){
		myarrayslength = myindexarray.length;
		if(myslideindex1 == myarrayslength - 1){
		    myrollovertextnext = myindexarray[0];
		}else{
			myrollovertextnext = myindexarray[myslideindex1 + 1];
		}
		$(".controlArrow.next .myrolltext").text(myrollovertextnext);
		$(".controlArrow.next .myrolltext").fadeIn('slow');
    },
    function(){
		$(".controlArrow.next .myrolltext").text(myrollovertextnext);
		$(".controlArrow.next .myrolltext").fadeOut('fast');
    }
);
		
        // devicewidth = screen.width;
        // breakintroloop = 0;
		
		 doctor5 = $("#doctor5"),
		 doctor4 = $("#doctor4"),
		 doctor12 = $("#doctor12"),
		 doctor2 = $("#doctor2"),
		 doctor3 = $("#doctor3"),
		 doctor6 = $("#doctor6"),
		 doctor7 = $("#doctor7"),
		 doctor8 = $("#doctor8"),
		 doctor9 = $("#doctor9"),
		 doctor10 = $("#doctor10"),
		 doctor1 = $("#doctor1"),
		 doctor11 = $("#doctor11"),
        	slide01_frame1_anim00 = $(".ThroidImg"),
			slide01_frame1_anim01 = $(".line1"),
			slide01_frame1_anim02 = $(".line2"),
			slide01_frame1_anim03 = $(".line3"),
			slide01_frame1_anim04 = $(".line4"),
			slide01_frame1_anim05 = $(".line5"),
			slide01_frame1_anim06 = $(".line6"),
			slide01_frame1_anim07 = $(".Txt1"),
			slide01_frame1_anim08 = $(".Txt2"),
			slide01_frame1_anim09 = $(".Txt3"),
			slide01_frame1_anim10 = $(".Txt4"),
			slide01_frame1_anim11 = $(".Txt5"),
			slide01_frame1_anim12 = $(".Txt6"),
			slide01_frame4_anim00 = $("#slide14_hypothyroidism"),
            slide01_frame4_anim01 = $(".Slide14CtntLft .Slide14Cont .slide14_icon1"),
            slide01_frame4_anim02 = $(".Slide14CtntLft .Slide14Cont .slide14_icon2"),
            slide01_frame4_anim03 = $(".Slide14CtntLft .Slide14Cont .slide14_icon3"),
            slide01_frame4_anim04 = $(".Slide14CtntLft .Slide14Cont .slide14_icon4"),
            slide01_frame4_anim05 = $(".Slide14CtntLft .Slide14Cont .slide14_icon5"),
            slide01_frame4_anim06 = $(".Slide14CtntLft .Slide14Cont .slide14_icon6"),
            slide01_frame4_anim07 = $(".Slide14CtntLft .Slide14Cont .slide14_icon7"),
            slide01_frame4_anim08 = $(".Slide14CtntLft .Slide14Cont .slide14_icon8"),
            slide01_frame4_anim10 = $("#slide14_hypothyroidism1"),
            slide01_frame4_anim11 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon1"),
            slide01_frame4_anim12 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon2"),
            slide01_frame4_anim13 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon3"),
            slide01_frame4_anim14 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon4"),
            slide01_frame4_anim15 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon5"),
            slide01_frame4_anim16 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon6"),
            slide01_frame4_anim17 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon7"),
            slide01_frame4_anim18 = $(".Slide14CtntRgt .Slide14Cont .slide14_icon8"),
            slide03_frame1_anim00 = $(".slide31img"),
            slide03_frame1_anim01 = $(".innr_crl img"),
            slide03_frame1_anim02 = $(".ico_iodine"),
            slide03_frame1_anim03 = $(".ico_thyroxine"),
            slide03_frame1_anim04 = $(".ico_pituitary"),
            slide03_frame1_anim05 = $(".ico_thyroiditis"),
            slide03_frame1_anim06 = $(".ico_graves"),
            slide03_frame1_anim07 = $(".txt_iodine"),
            slide03_frame1_anim08 = $(".txt_thyroxine"),
            slide03_frame1_anim09 = $(".txt_pituitary"),
            slide03_frame1_anim10 = $(".txt_thyroiditis"),
            slide03_frame1_anim11 = $(".txt_graves"),
            slide03_frame2_anim00 = $(".slide32img"),
            slide03_frame2_anim01 = $(".slide32txt"),            
			slide03_frame2_anim02 = $(".div_autoimmune"),
            slide03_frame2_anim03 = $(".div_genetic"),
            slide03_frame2_anim04 = $(".div_surgery"),
            slide03_frame2_anim05 = $(".div_radiation"),
            slide03_frame2_anim06 = $(".div_hyperthyroidism"),
            slide03_frame2_anim07 = $(".div_pituitarygland"),
            slide03_frame2_anim08 = $(".div_medication"),
            slide03_frame2_anim09 = $("#slide32 .Slide2Content"),
			slide04_frame1_anim00 = $("#slide41 .Slide2Content .imgslide4_1"),
            slide04_frame1_anim01 = $("#slide41 .Slide2Content h4"),
            slide04_frame1_anim02 = $("#slide41 .Slide2Content p"),
            slide04_frame1_anim03 = $(".Slide41CtntRgt"),
            slide04_frame1_anim04 = $(".imgslide4_cir1"),
            slide04_frame1_anim05 = $(".imgslide4_cir2"),
            slide04_frame1_anim06 = $(".imgslide4_cir3"),
            slide04_frame1_anim07 = $(".imgslide4_cir4"),
            slide04_frame1_anim08 = $(".imgslide4_cir5"),
			slide04_frame2_anim00 = $("#slide42 .Slide2Content .imgslide4_2 .MidImg"),
            slide04_frame2_anim01 = $("#slide42 .Slide2Content h4"),
            slide04_frame2_anim02 = $("#slide42 .Slide2Content p"),
            slide04_frame2_anim03 = $(".imgslide4_2 .innr_crltxt"),
            slide04_frame2_anim04 = $(".imgslide4_2 .ico_disorder1"),
            slide04_frame2_anim05 = $(".imgslide4_2 .ico_disorder2"),
            slide04_frame2_anim06 = $(".imgslide4_2 .ico_disorder3"),
            slide04_frame2_anim07 = $(".imgslide4_2 .ico_disorder4"),
            slide04_frame2_anim08 = $(".imgslide4_2 .txt_disorder1"),
            slide04_frame2_anim09 = $(".imgslide4_2 .txt_disorder2"),
            slide04_frame2_anim10 = $(".imgslide4_2 .txt_disorder3"),
            slide04_frame2_anim11 = $(".imgslide4_2 .txt_disorder4"),
			slide04_frame2_anim12 = $(".imgslide4_2 .txt_disorder5"),
			slide04_frame21_anim00 = $("#slide421 .Slide2Content .imgslide4_21 .MidImg"),
            slide04_frame21_anim01 = $("#slide421 .Slide2Content h4"),
            slide04_frame21_anim02 = $("#slide421 .Slide2Content p"),
            slide04_frame21_anim03 = $(".imgslide4_21 .innr_crltxt"),
            slide04_frame21_anim04 = $(".imgslide4_21 .ico_disorder1"),
            slide04_frame21_anim05 = $(".imgslide4_21 .ico_disorder2"),
            slide04_frame21_anim06 = $(".imgslide4_21 .ico_disorder3"),
            slide04_frame21_anim07 = $(".imgslide4_21 .ico_disorder4"),
            slide04_frame21_anim08 = $(".imgslide4_21 .txt_disorder1"),
            slide04_frame21_anim09 = $(".imgslide4_21 .txt_disorder2"),
            slide04_frame21_anim10 = $(".imgslide4_21 .txt_disorder3"),
            slide04_frame21_anim11 = $(".imgslide4_21 .txt_disorder4"),
			slide04_frame21_anim12 = $(".imgslide4_21 .txt_disorder5"),
			slide04_frame3_anim00 = $(".imgmain43"),
            slide04_frame3_anim01 = $(".Img_depression1"),
            slide04_frame3_anim02 = $(".Img_deparrow1"),
            slide04_frame3_anim03 = $(".Img_deparrow2"),
            slide04_frame3_anim04 = $(".Img_deparrow3"),
            slide04_frame3_anim05 = $(".Img_deparrow4"),
            slide04_frame3_anim06 = $(".Img_deparrow5"),
            slide04_frame3_anim07 = $(".Img_deparrow6"),
            slide04_frame3_anim08 = $(".Img_deparrow7"),
            slide04_frame3_anim09 = $(".Img_deparrow8"),
            slide04_frame3_anim10 = $(".Txt_deparrow1"),
            slide04_frame3_anim11 = $(".Txt_deparrow2"),
            slide04_frame3_anim12 = $(".Txt_deparrow3"),
            slide04_frame3_anim13 = $(".Txt_deparrow4"),
            slide04_frame3_anim14 = $(".Txt_deparrow5"),
            slide04_frame3_anim15 = $(".Txt_deparrow6"),
            slide04_frame3_anim16 = $(".Txt_deparrow7"),
            slide04_frame3_anim17 = $(".Txt_deparrow8"),
            slide04_frame3_anim18 = $(".Slide43CtntRgt"),
            slide04_frame4_anim00 = $(".Slide44CtntLft .slide4-4img"),
            slide04_frame4_anim01 = $(".Slide44CtntLft .icon1"),
            slide04_frame4_anim02 = $(".Slide44CtntLft .icon2"),
            slide04_frame4_anim03 = $(".Slide44CtntLft .icon3"),
            slide04_frame4_anim04 = $(".Slide44CtntLft .icon4"),
            slide04_frame4_anim05 = $(".Slide44CtntLft .icon1Txt"),
            slide04_frame4_anim06 = $(".Slide44CtntLft .icon2Txt"),
            slide04_frame4_anim07 = $(".Slide44CtntLft .icon3Txt"),
            slide04_frame4_anim08 = $(".Slide44CtntLft .icon4Txt"),
            slide04_frame4_anim09 = $(".Slide44CtntRgt"),
            slide05_frame1_anim00 = $(".slide5-1img"),
            slide05_frame1_anim01 = $(".Slide51CtntLft .icon1"),
            slide05_frame1_anim02 = $(".Slide51CtntLft .icon2"),
            slide05_frame1_anim03 = $(".Slide51CtntLft .icon3"),
            slide05_frame1_anim04 = $(".Slide51CtntLft .icon4"),
            slide05_frame1_anim05 = $(".Slide51CtntLft .icon5"),
            slide05_frame1_anim06 = $(".Slide51CtntLft .icon6"),
            slide05_frame1_anim07 = $(".Slide51CtntLft .icon1Txt"),
            slide05_frame1_anim08 = $(".Slide51CtntLft .icon2Txt"),
            slide05_frame1_anim09 = $(".Slide51CtntLft .icon3Txt"),
            slide05_frame1_anim10 = $(".Slide51CtntLft .icon4Txt"),
            slide05_frame1_anim11 = $(".Slide51CtntLft .icon5Txt"),
            slide05_frame1_anim12 = $(".Slide51CtntLft .icon6Txt"),
            slide05_frame1_anim13 = $(".Slide51CtntRgt"),
            slide05_frame2_anim00 = $(".Slide52CtntLft"),
            slide05_frame2_anim01 = $(".slide5-2img"),
            slide05_frame2_anim02 = $(".Slide52CtntRgt .bgicon1"),
            slide05_frame2_anim03 = $(".Slide52CtntRgt .bgicon2"),
            slide05_frame2_anim04 = $(".Slide52CtntRgt .bgicon3"),
            slide05_frame2_anim05 = $(".Slide52CtntRgt .bgicon4"),
            slide05_frame2_anim06 = $(".Slide52CtntRgt .bgicon5"),
            slide05_frame2_anim07 = $(".Slide52CtntRgt .icon1"),
            slide05_frame2_anim08 = $(".Slide52CtntRgt .icon2"),
            slide05_frame2_anim09 = $(".Slide52CtntRgt .icon3"),
            slide05_frame2_anim10 = $(".Slide52CtntRgt .icon4"),
            slide05_frame2_anim11 = $(".Slide52CtntRgt .icon5"),
            slide05_frame2_anim12 = $(".Slide52CtntRgt .lnk_explore"),
            slide05_frame3_anim00 = $(".slide5-3img"),
            slide05_frame3_anim01 = $(".Slide53CtntLft .icon1"),
            slide05_frame3_anim02 = $(".Slide53CtntLft .icon2"),
            slide05_frame3_anim03 = $(".Slide53CtntLft .icon3"),
            slide05_frame3_anim04 = $(".Slide53CtntLft .icon4"),
            slide05_frame3_anim05 = $(".Slide53CtntLft .icon5"),
            slide05_frame3_anim06 = $(".Slide53CtntLft .icon6"),
            slide05_frame3_anim07 = $(".Slide53CtntRgt"),
            slide05_frame4_anim00 = $(".Slide54Ctnt .Slide54Img"),
            slide05_frame4_anim01 = $(".Slide54Ctnt .bgicon1"),
            slide05_frame4_anim02 = $(".Slide54Ctnt .bgicon2"),
            slide05_frame4_anim03 = $(".Slide54Ctnt .bgicon3"),
            slide05_frame4_anim04 = $(".Slide54Ctnt .bgicon4"),
            slide05_frame4_anim05 = $(".Slide54Ctnt .bgicon5"),
            slide05_frame4_anim06 = $(".Slide54Ctnt .bgicon6"),
            slide05_frame4_anim07 = $(".Slide54Ctnt .bgicon7"),
            slide05_frame4_anim08 = $(".Slide54Ctnt .bgicon8"),
            slide05_frame4_anim09 = $(".Slide54Ctnt .icon1"),
            slide05_frame4_anim10 = $(".Slide54Ctnt .icon2"),
            slide05_frame4_anim11 = $(".Slide54Ctnt .icon3"),
            slide05_frame4_anim12 = $(".Slide54Ctnt .icon4"),
            slide05_frame4_anim13 = $(".Slide54Ctnt .icon5"),
            slide05_frame4_anim14 = $(".Slide54Ctnt .icon6"),
            slide05_frame4_anim15 = $(".Slide54Ctnt .icon7"),
            slide05_frame4_anim16 = $(".Slide54Ctnt .icon8"),
            slide05_frame4_anim17 = $(".Slide54Ctnt .icon1Txt"),
            slide05_frame4_anim18 = $(".Slide54Ctnt .icon2Txt"),
            slide05_frame4_anim19 = $(".Slide54Ctnt .icon3Txt"),
            slide05_frame4_anim20 = $(".Slide54Ctnt .icon4Txt"),
            slide05_frame4_anim21 = $(".Slide54Ctnt .icon5Txt"),
            slide05_frame4_anim22 = $(".Slide54Ctnt .icon6Txt"),
            slide05_frame4_anim23 = $(".Slide54Ctnt .icon7Txt"),
            slide05_frame4_anim24 = $(".Slide54Ctnt .icon8Txt"),
            slide05_frame5_anim00 = $("#slide55 h4"),
            slide05_frame5_anim01 = $("#slide55 p"),
            slide05_frame5_anim02 = $(".imgslide5_5"),
            slide05_frame5_anim03 = $(".slide55box1"),
            slide05_frame5_anim04 = $(".slide55box2"),
            slide05_frame6_anim00 = $("#slide56 h4"),
            slide05_frame6_anim01 = $("#slide56 p"),
            slide05_frame6_anim02 = $(".imgslide5_6"),
            slide05_frame6_anim03 = $(".slide56box"),
			slide07_frame1_anim00 = $(".TreatmentTxt1"),
			slide07_frame1_anim01 = $(".TreatmentArrow1"),
			slide07_frame1_anim02 = $(".TreatmentTxt2"),
			slide07_frame1_anim03 = $(".TreatmentArrow2"),
			slide07_frame1_anim04 = $(".TreatmentTxt3"),
			slide07_frame1_anim05 = $(".TreatmentArrow3"),
			slide07_frame1_anim06 = $(".TreatmentTxt4"),
			slide07_frame1_anim07 = $(".TreatmentArrow4"),
			slide07_frame1_anim08 = $(".TreatmentTxt5"),
			slide07_frame1_anim09 = $(".TreatmentArrow5"),
			slide07_frame1_anim10 = $(".TreatmentTxt6"),
			slide07_frame1_anim11 = $(".TreatmentArrow6"),
			slide07_frame1_anim12 = $(".TreatmentTxt7"),
			slide07_frame1_anim13 = $(".TreatmentTxt8"),			
            main01_anim00 = $(".firstd1"),
            main01_anim01 = $(".firstd2"),
            main01_anim02 = $(".firstd3"),
            main01_anim03 = $(".firstd4"),
            main01_anim04 = $(".firstd5"),
            main01_anim05 = $(".firstd6"),
            main01_anim06 = $(".firstd7"),
            main01_anim07 = $(".firstd8"),
            main01_anim08 = $(".firstd9"),
            UpArrowAnim = $(".UpArrowAnim"),
            DwnArrowAnim = $(".DwnArrowAnim"),
            anim0_LftDwnlogo = $(".thyroid_life"),
            anim0_RgtDwnlogo = $(".thyroid_assist_center"),
            playbtn = $(".playbtn"),
            playbtn1 = $(".playbtn1"),
            playbtn2 = $(".playbtn2"),
            card2Tooltip = $(".card2Tooltip"),
			nextarrow = $(".nextarrow"),
			prevarrow = $(".prevarrow"),
			IntroDiv = $("#IntroDiv"),
			IntroDiv2 = $("#IntroDiv2"),
			whatisthyroid = $("#whatisthyroid"),
			MenuImg1 = $(".MenuImg1"),
			MenuImg2 = $(".MenuImg2"),
			MenuImg3 = $(".MenuImg3"),
			Feedback = $(".PageFeedback");
			
			TweenLite.to(playbtn1, 0, {scale: .8})
			TweenLite.to(playbtn2, 0, {scale: 1, left:48+"%"})
			
			var vplaybtn = new TimelineLite({onComplete: videoplay});
        	vplaybtn.to(playbtn1, 1, {opacity: 0, scale: 1}, "playbtns")
			  .to(playbtn2, 1, {opacity: 0, scale: 1.2}, "playbtns")
			
			function videoplay() {
            	vplaybtn.restart();
        	}
			
			var slidebtns = new TimelineLite({onComplete: slideplays});
        		slidebtns.to(prevarrow, 1, {opacity: 0, left: -10})
        				.to(nextarrow, 1, {opacity: 0, left: 10})
			
			function slideplays() {
            	slidebtns.restart();
        	}
			
        MenuBar = $(".MenuBar");
        ThyroidAssist = $(".thyroid_assist");
        Popup_AssistImg = $("#popup_assist");
        //MenuCloseIcon = $(".MenuCloseIcon");

        animateheight = $(window).height();
        objheight = animateheight - 120;
        $(".thyroid_assist").css("top", -animateheight);
        $(".thyroid_assist").css("height", animateheight);
        $(".MenuBar").css("height", animateheight);
        $("#symptoms_iframe").css("height", animateheight);
        $("#gallery_iframe").css("height", animateheight - 100);
        $("#news_iframe").css("height", animateheight - 100);
        $(".AnimatedDoctors").css("height", objheight);
        $(".AnimatedDoctorsimg").css("height", objheight);

        function changetext(newtext) {
            $("#TextHead").text(newtext)
        }

        function changetext1(newtext) {
            $("#Text").text(newtext)
        }

        function changetext2(newtext) {
            $("#Text1").text(newtext)
        }
		function LoaderRef(newtext) {
            $("#LoaderRef").text(newtext)
        }
		function LoaderRef2(newtext) {
            $("#LoaderRef2").text(newtext)
        }
		function LoaderRef3(newtext) {
            $("#LoaderRef3").text(newtext)
        }

        tl = new TimelineLite({
            onComplete: repeatTimeline
        });
        tl.to(doctor6, 1, {left: "45%",opacity: 1})
            .to(doctor7, 1, {left: "38%",opacity: 1,scale: .95}, "anim01")
            .to(doctor1, 1, {left: "52%",opacity: 1,scale: .95}, "anim01")
            .call(changetext, ["#1"], "anim01")
            .call(changetext1, ["In India, about 45 million people suffer from coronary artery disease"], "anim01")
            .call(changetext2, [""], "anim01")
			.call(LoaderRef, [""], "anim01")
			.call(LoaderRef2, [""], "anim01")
			.call(LoaderRef3, [""], "anim01")
            .to(doctor8, 1, {left: "32%",opacity: 1,scale: .85}, "anim012")
            .to(doctor11, 1, {left: "57%",opacity: 1,scale: .85}, "anim012")
            .to(doctor2, 1, {left: "27%",opacity: 1,scale: .75}, "anim013")
            .to(doctor3, 1, {left: "63%",opacity: 1,scale: .75}, "anim013")
            .to(doctor5, 1, {left: "22%",opacity: 1,scale: .65}, "anim014")
            .to(doctor4, 1, {left: "68%",opacity: 1,scale: .65}, "anim014")
			.to(doctor12, 1, {left: "18%",opacity: 1,scale: .55}, "anim015")
            .to(AnimateInroTxt, 2, {opacity: 1}, "anim012")

        .to(doctor6, 1, {left: "45%",opacity: 0,delay: 2}, "anim021")
            .to(AnimateInroTxt, 1, {opacity: 0,delay: 1}, "anim021")
			.set(doctor8, {attr: {src: 'static/img/doctor-img1.png'}})
			.set(doctor4, {attr: {src: 'static/img/doctor-img2.png'}})
            .call(changetext, ["#2"], "anim02")
            .call(changetext1, ["Malnutrition is still the single largest risk factor responsible for 15% of the total disease burden in India"], "anim02")
            .call(changetext2, [""], "anim02")
			.call(LoaderRef, [""], "anim02")
			.call(LoaderRef2, [""], "anim02")
			.call(LoaderRef3, [""], "anim02")
            .to(doctor7, 1, {left: "45%",opacity: 1,scale: 1}, "anim02")
            .to(doctor1, 1, {left: "57%",opacity: 1,scale: .85}, "anim02")
            .to(doctor8, 1, {left: "38%",opacity: 1,scale: .95}, "anim02")
            .to(doctor11, 1, {left: "57%",opacity: 0,scale: .85}, "anim02")
            .to(doctor2, 1, {left: "33%",opacity: 1,scale: .85}, "anim02")
            .to(doctor3, 1, {left: "63%",opacity: 0,scale: .85}, "anim02")
            .to(doctor5, 1, {left: "40%",opacity: 0,scale: .85}, "anim02")
            .to(doctor4, 1, {left: "52%",opacity: 1,scale: .95}, "anim02")
			.to(doctor12, 1, {left: "52%",opacity: 0,scale: .65}, "anim02")
			.set(doctor4, {css: {zIndex: 24}}, "anim02")
            .to(AnimateInroTxt, 1, {opacity: 1}, "anim02")

        .to(AnimateInroTxt, 1, {opacity: 0,delay: 2}, "frame2")
            .set(doctor7, {attr: {src: 'static/img/doctor-img1.png'}})
            .set(doctor5, {attr: {src: 'static/img/doctor-img1.png'}})

        	.call(changetext, ["3X"], "frame2")
			.call(changetext, ["#3"], "anim02")
            .call(changetext1, ["25% of Indians may die of lifestyle diseases before they are 70"], "frame2")
            .call(changetext2, [""], "frame2")
			.call(LoaderRef, [""], "frame2")
            .call(LoaderRef2, [""], "frame2")
			.call(LoaderRef3, [""], "frame2")
			.to(doctor7, 1, {left: "20%",opacity: 1,scale: .95}, "anim03")
            .to(doctor1, 1, {left: "72%",opacity: 1,scale: .95}, "anim03")
            .to(doctor8, 1, {left: "33%",opacity: 1,scale: .95}, "anim03")
            .to(doctor11, 1, {left: "57%",opacity: 0,scale: .85}, "anim03")
            .to(doctor2, 1, {left: "33%",opacity: 0,scale: .85}, "anim03")
            .to(doctor3, 1, {left: "63%",opacity: 0,scale: .85}, "anim03")
            .to(doctor5, 1, {left: "46%",opacity: 1,scale: .95}, "anim03")
			.to(doctor9, 1, {left: "59%",opacity: 1,scale: .95}, "anim03")
            .to(doctor4, 1, {left: "52%",opacity: 0,scale: .95}, "anim03")
            .to(AnimateInroTxt, 1, {opacity: 1}, "anim03")

        .to(AnimateInroTxt, 1, {opacity: 0, delay:1}, "anim04")
            .call(changetext, ["#4"], "anim04")
            .call(changetext1, ["of hypothyroid patients may be suffering from constipation"], "anim04")
            .call(changetext2, [""], "anim04")
			.call(LoaderRef, [""], "anim04")
			.call(LoaderRef2, [""], "anim04")
			.call(LoaderRef3, [""], "anim04")
            .to(doctor6, 1, {left: "47%",opacity: 0,scale: .95,delay: 1}, "anim041")
            .to(doctor8, 1, {left: "45%",opacity: 1,scale: 1}, "anim041")
            .to(doctor1, 1, {left: "58%",opacity: 0,scale: .95}, "anim041")
            .to(doctor7, 1, {left: "10%",opacity: 0,scale: .95}, "anim041")
            .to(doctor1, 1, {left: "56%",opacity: 1,scale: .95}, "anim041")
            .to(doctor2, 1, {left: "35%",opacity: 1,scale: .95}, "anim041")
            .to(doctor11, 1, {left: "57%",opacity: 0,scale: .85}, "anim041")
            .to(doctor3, 1, {left: "63%",opacity: 0,scale: .85}, "anim041")
            .to(doctor5, 1, {left: "40%",opacity: 0,scale: .85}, "anim041")
            .to(doctor4, 1, {left: "52%",opacity: 0,scale: .95}, "anim041")
			.to(doctor9, 1, {left: "54%",opacity: 0,scale: .95}, "anim041")
            .to(AnimateInroTxt, 1, {opacity: 1}, "anim042")

         .to(AnimateInroTxt, 1, {opacity: 0}, "anim05")
            .to(doctor2, 1, {left: "38%",opacity: 1,scale: .95,delay: 1}, "anim05")
            .to(doctor1, 1, {left: "52%",opacity: 1,scale: .95,delay: 1}, "anim05")
				.set(doctor11, {css: {zIndex: 19}}, "anim05")
				.set(doctor5, {attr: {src: 'static/img/doctor-img3.png'}}, "anim05")
				.to(doctor9, 1, {left: "32%"}, "anim05")
            .call(changetext, ["#5"], "anim05")
            .call(changetext1, ["Sedentary lifestyle is a major cause of death due to heart disease"], "anim05")
            .call(changetext2, [""], "anim05")
			.call(LoaderRef, [""], "anim05")
			.call(LoaderRef2, [""], "anim05")
			.call(LoaderRef3, [""], "anim05")
            .to(doctor11, 1, {left: "32%",opacity: 1,scale: .85}, "anim051")
            .to(doctor5, 1, {left: "59%",opacity: 1,scale: .85}, "anim051")
			.to(doctor9, 1, {left: "26%",opacity: 1,scale: .75}, "anim052")
            .to(AnimateInroTxt, 1, {opacity: 1}, "anim051")
			
			.to(AnimateInroTxt, 1, {opacity: 0,delay:3}, "anim06")
			.to(doctor2, 1, {left: "48%",opacity: 0,scale: .75}, "anim07")
			.to(doctor1, 1, {left: "42%",opacity: 0,scale: .95}, "anim07")
			.to(doctor11, 1, {left: "42%",opacity: 0,scale: .85}, "anim07")
			.to(doctor5, 1, {left: "47%",opacity: 0,scale: .65}, "anim07")
			.to(doctor9, 1, {left: "42%",opacity: 0,scale: .65}, "anim07")

        ;
        var myVar = setInterval(function() {
            loopinterval()
        }, 1000);

        function myStopFunction() {
            clearInterval(myVar);
        }

		Fn_Menu = function() {
			menu.to(MenuImg1, 1, {opacity: 1, left:0})
				.to(MenuImg2, 1, {opacity: 1,left:0, delay: 1})
				.to(MenuImg3, 1, {opacity: 1,left:0, delay: 1})
				menu.timeScale(2);
		}

        function loopinterval() {
            if (breakintroloop == 1) {
                myStopFunction();
				TweenLite.to(IntroDiv, 1, {opacity: 0,delay:2, onComplete: function () {
		
					//alert(surl);
					
					$("#thyroidlifeimg").attr('src', 'images/thyroid_life.png');
					
					if (surl == "" || surl == "index.aspx") {
							//TweenLite.to(IntroDiv2, 1, {opacity: 1,delay:1});
							
							fn_skiptoframe = function(){
								if (myprevindex == 2 && mycurrentindex == 3){
									$.fn.fullpage.moveTo(4);
								}else if(myprevindex == 4 && mycurrentindex == 3){
									$.fn.fullpage.moveTo(2);
								}
							}
							

					TweenLite.to(anim0_RgtDwnlogo, 0.5, {opacity: 1});
					$.fn.fullpage.moveTo(2);
					Fn_Menu();
					TweenLite.to(MenuBar, 0.7, {opacity: 1,left: 0,delay: 2});
					TweenLite.to(MenuBar, 1.5, {opacity: 0, left: -350, delay: 5});
					
				}else{
					TweenLite.to(anim0_RgtDwnlogo, 0.5, {opacity: 1});
					Fn_Menu();
				}
				if (surl == "intro") {
					//alert(1);
					TweenLite.to(IntroDiv, 1, {opacity: 1});
					$("#ScrollDiv").css("display","block");
					$("#ScrollDiv").css("bottom",60);
					$("#ScrollTxt").html("Scroll down to What is Thyroid Disorder");
					mymenurollover = 1;	
					MouseTrueFPage();
					mynewvar =1;
					mypassvar = 1;
				}
				if (surl == "whatisthyroid") {
					$.fn.fullpage.moveTo(2);
					mymenurollover = 1;		
				} 
				
				if (surl == "symptoms") {
					$.fn.fullpage.moveTo(3);
					mymenurollover = 1;
				}
				if (surl == "causes") {
					$.fn.fullpage.moveTo(4);
					mymenurollover = 1;
				}
				if (surl == "prevalence") {
					$.fn.fullpage.moveTo(5);
					mymenurollover = 1;
				}
				if (surl == "pregnancy") {
					$.fn.fullpage.moveTo(6);
					mymenurollover = 1;
				}
				if (surl == "diagnosis") {
					$.fn.fullpage.moveTo(7);
					mymenurollover = 1;
				}
				if (surl == "gallery") {
					$.fn.fullpage.moveTo(8);
					mymenurollover = 1;
				}
				if (surl == "news") {
					$.fn.fullpage.moveTo(9);
					mymenurollover = 1;
				}
				if (surl == "faqs") {
					$.fn.fullpage.moveTo(10);
					mymenurollover = 1;
				} 

			}});
				
                }
	        }
		
        function repeatTimeline() {
				tl.restart();
        }

		Fn_ScrollToFacts = function () {
			repeatTimeline();
			$.fn.fullpage.moveTo(1);
			TweenLite.to(IntroDiv, 1, {opacity: 1},'Facts');
			TweenLite.to(IntroDiv2, 0, {opacity: 0},'Facts');
			TweenLite.to(MenuBar, 0.7, {opacity: 0,left: -300},'Facts');
			$("#ScrollDiv").css('display','block');
			mypassvar = 1;
			
		}


        $("#card").flip({axis: 'y',trigger: 'hover',});
        $("#card2").flip({axis: 'y',trigger: 'hover',});

		$(".thyroid_assist_center").hover(
            function() {
				$(".bg2").css("opacity","1");
				TweenLite.to(card2Tooltip, 0, {display: 'block'});
                TweenLite.to(card2Tooltip, 1, {top: "-50",opacity: 1});
				var t15 = new TimelineLite();
            	t15.to(main01_anim00, 1, {opacity: 1}, 'anim15')
					.to(main01_anim01, 1, {opacity: 1,delay: 1}, 'anim15')
					.to(main01_anim02, 1, {opacity: 1,delay: 2}, 'anim15')
					.to(main01_anim03, 1, {opacity: 1,delay: 3}, 'anim15')
					.to(main01_anim04, 1, {opacity: 1,delay: 4}, 'anim15')
					.to(main01_anim05, 1, {opacity: 1,delay: 5}, 'anim15')
					.to(main01_anim06, 1, {opacity: 1,delay: 6}, 'anim15')
					.to(main01_anim07, 1, {opacity: 1,delay: 7}, 'anim15')
					.to(main01_anim08, 1, {opacity: 1,delay: 8}, 'anim15');
            	t15.timeScale(6);
            },
            function() {
                TweenLite.to(card2Tooltip, 1, {top: "-80",opacity: 0});
				TweenLite.to(card2Tooltip, 0, {display: 'none',delay:1});
				$("#card2 .bg2").css('opacity', 0);
				var t16 = new TimelineLite();
				t16.to(main01_anim00, 0, {opacity: 0}, 'anim16')
					.to(main01_anim01, 0, {opacity: 0}, 'anim16')
					.to(main01_anim02, 0, {opacity: 0}, 'anim16')
					.to(main01_anim03, 0, {opacity: 0}, 'anim16')
					.to(main01_anim04, 0, {opacity: 0}, 'anim16')
					.to(main01_anim05, 0, {opacity: 0}, 'anim16')
					.to(main01_anim06, 0, {opacity: 0}, 'anim16')
					.to(main01_anim07, 0, {opacity: 0}, 'anim16')
					.to(main01_anim08, 0, {opacity: 0}, 'anim16');
				t16.timeScale(9);
            }
        );
		
        $(".MenuHome").click(function() {
           if(mymenurollover == 1){
			   Fn_ScrollToThyroid(1);
		   }
        });

		function MouseFalseFPage(){
			$.fn.fullpage.setMouseWheelScrolling(false);
    		$.fn.fullpage.setAllowScrolling(false);	
			$.fn.fullpage.setKeyboardScrolling(false);
			mymenurollover = 0;
		}
		function MouseTrueFPage(){
			$.fn.fullpage.setMouseWheelScrolling(true);
    		$.fn.fullpage.setAllowScrolling(true);
			$.fn.fullpage.setKeyboardScrolling(true);	
			mymenurollover = 1;
		}
		
        $(".MenuAbbott").mouseover(function() {
			if(mymenurollover == 1){
            	TweenLite.to(MenuBar, 0.7, {opacity: 1,left: 0});
			}
			MouseFalseFPage();
        });
		$(".MenuBar").hover(
            function() {
				TweenLite.to(MenuBar, 0.7, {opacity: 1,left: 0});
				MouseFalseFPage();
            },
            function() {
                TweenLite.to(MenuBar, 0.7, {opacity: 0,left: -300});
				MouseTrueFPage();
            }
        );
		$(".PageFeedback").hover(
            function() {
				TweenLite.to(Feedback, 0.7, {right: 0});
            },
            function() {
                TweenLite.to(Feedback, 0.7, {right: -75});
            }
        );
        $(".logo").click(function() {
			Fn_closeThyroidAssist();
			if(mymenurollover == 1){
				Fn_ScrollToFacts();	
			}
			
        });
        $(".thyroid_life").click(function() {
			if(mymenurollover == 1){
            	Fn_ScrollToFacts();
			}
        });
		$(".arrow_top img").click(function() {
			$.fn.fullpage.moveTo(1,0);
        });
		
        var arrow = new TimelineLite({
            onComplete: repeatTimelineArrow
        });
		
        arrow.to(UpArrowAnim, 1.5, {top: 0,opacity: 1}, "animatearrow")
            .to(DwnArrowAnim, 1.5, {top: 0,opacity: 1}, "animatearrow")

        function repeatTimelineArrow() {
            arrow.restart();
        }
    });

function MouseFalseFPage1(){
	setTimeout(function(){ 
		$.fn.fullpage.setMouseWheelScrolling(false);
		$.fn.fullpage.setAllowScrolling(false);	
		$.fn.fullpage.setKeyboardScrolling(false);
	}, 800);
}
function MouseTrueFPage1(){
	setTimeout(function(){ 
		$.fn.fullpage.setMouseWheelScrolling(true);
		$.fn.fullpage.setAllowScrolling(true);
		$.fn.fullpage.setKeyboardScrolling(true);
	}, 800);	
}

function Fn_hidemenu(){
	TweenLite.to(MenuBar, 0.7, {opacity: 0,left: -300});
	Fn_closeThyroidAssist();
	fn_assistpopupclose(0);
}

function fn_consultadoc(){
	TweenLite.to(ThyroidAssist, 1, {opacity: 1,top: 0});
	TweenLite.to(Popup_AssistImg, 2, {opacity: 1});
	MouseFalseFPage1();
}
function Fn_ScrollToHome() {
    $.fn.fullpage.moveTo(1);
    Fn_hidemenu();
}

function Fn_ScrollToThyroid(myvar) {
	$("#whatisthyroid").css('opacity','1');
	$("#ScrollDiv").css('display','block');	
	if(myvar == 0){
		$.fn.fullpage.moveTo(2,0);
		Fn_hidemenu();
		TweenLite.to(IntroDiv, 0, {opacity: 0});
		mypassvar = 0;
	} else if(myvar == 1){
		$.fn.fullpage.moveTo(2,0);
		Fn_hidemenu();
		TweenLite.to(IntroDiv, 0, {opacity: 0});
		mypassvar = 0;
	} else if(myvar == 2){
		$.fn.fullpage.moveTo(2,1);
		Fn_hidemenu();
		TweenLite.to(IntroDiv, 0, {opacity: 0});
		mypassvar = 0;
	} else if(myvar == 3){
		$.fn.fullpage.moveTo(2,2);
		Fn_hidemenu();
		TweenLite.to(IntroDiv, 0, {opacity: 0});
		mypassvar = 0;
	} else if(myvar == 4){
		$.fn.fullpage.moveTo(2,3);
		//$.fn.fullpage.moveSlideRight();
		Fn_hidemenu();
		TweenLite.to(IntroDiv, 0, {opacity: 0});
		mypassvar = 0;
	}
}
function Fn_ScrollToSymptoms(myvar) {
	$.fn.fullpage.moveTo(3);
	Fn_hidemenu();
}
function Fn_ScrollToCauses(myvar) {
	if(myvar == 0){
		$.fn.fullpage.moveTo(4,0);
    	Fn_hidemenu();
	} else if(myvar == 1){
		$.fn.fullpage.moveTo(4,0);
    	Fn_hidemenu();
	} else if(myvar == 2){
		$.fn.fullpage.moveTo(4,1);
    	Fn_hidemenu();
	}
}

function Fn_ScrollToPrevalence(myvar) {
	mySlide41=2;
	if(myvar == 0){
		$.fn.fullpage.moveTo(5,0);
		Fn_hidemenu();
	} else if(myvar == 1){
		$.fn.fullpage.moveTo(5,0);
		Fn_hidemenu();
	} else if(myvar == 2){
		$.fn.fullpage.moveTo(5,1);
		Fn_hidemenu();
	} else if(myvar == 3){
		$.fn.fullpage.moveTo(5,3);
		Fn_hidemenu();
	} else if(myvar == 4){
		$.fn.fullpage.moveTo(5,4);
		Fn_hidemenu();
	}
}

function Fn_ScrollToPregnancy(myvar) {
	if(myvar == 0){
		$.fn.fullpage.moveTo(6,0);
		Fn_hidemenu();
	} else if(myvar == 1){
		$.fn.fullpage.moveTo(6,0);
		Fn_hidemenu();
	} else if(myvar == 2){
		$.fn.fullpage.moveTo(6,1);
		Fn_hidemenu();
	} else if(myvar == 3){
		$.fn.fullpage.moveTo(6,3);
		Fn_hidemenu();
	} else if(myvar == 4){
		$.fn.fullpage.moveTo(6,4);
		Fn_hidemenu();
	} else if(myvar == 5){
		$.fn.fullpage.moveTo(6,5);
		Fn_hidemenu();
	}
}

function Fn_ScrollToDiagnosis() {
    $.fn.fullpage.moveTo(7);
    Fn_hidemenu();
}

function Fn_ScrollToGallery() {
    $.fn.fullpage.moveTo(8);
    Fn_hidemenu();
}

function Fn_ScrollToNews() {
    $.fn.fullpage.moveTo(9);
    Fn_hidemenu();
}

function Fn_ScrollToFaqs() {
    $.fn.fullpage.moveTo(10);
    Fn_hidemenu();
}

function Fn_SlideRight() {
    $.fn.fullpage.moveSlideRight();
    Fn_hidemenu();
}


mySlide14 = 0;

function Fn_Slide14() {
	
	$(".imgslide2_2").css({ opacity: 1});
	
	if(mySlide14==1){
		$(".Slide14CtntLft").css('opacity',0);
	t2.restart();	
		
		
	}else{
		t2.to($(".Slide14CtntLft"), .2, {opacity: 1}, 'startlft')
		.to(slide01_frame4_anim00, 1, {opacity: 1,scaleX: 1,scaleY: 1,delay: 1}, 'startlft')
        .to(slide01_frame4_anim01, .5, {opacity: 1,left: 157,top: 7,delay: 2}, 'startlft')
        .to(slide01_frame4_anim02, .5, {opacity: 1,left: 291,top: 71,delay: 3}, 'startlft')
        .to(slide01_frame4_anim03, .5, {opacity: 1,left: 320,top: 164,delay: 4}, 'startlft')
        .to(slide01_frame4_anim04, .5, {opacity: 1,left: 283,top: 260,delay: 5}, 'startlft')
        .to(slide01_frame4_anim05, .5, {opacity: 1,left: 155,top: 313,delay: 6}, 'startlft')
        .to(slide01_frame4_anim06, .5, {opacity: 1,left: 26,top: 260,delay: 7}, 'startlft')
        .to(slide01_frame4_anim07, .5, {opacity: 1,left: -11,top: 164,delay: 8}, 'startlft')
        .to(slide01_frame4_anim08, .5, {opacity: 1,left: 19,top: 71,delay: 9}, 'startlft')
    	.to(slide01_frame4_anim10, 1, {opacity: 1,scaleX: 1,scaleY: 1,delay: 1}, 'startrgt')
        .to(slide01_frame4_anim11, .5, {opacity: 1,left: 150,top: 7,delay: 2}, 'startrgt')
        .to(slide01_frame4_anim12, .5, {opacity: 1,left: 288,top: 71,delay: 3}, 'startrgt')
        .to(slide01_frame4_anim13, .5, {opacity: 1,left: 327,top: 164,delay: 4}, 'startrgt')
        .to(slide01_frame4_anim14, .5, {opacity: 1,left: 283,top: 260,delay: 5}, 'startrgt')
        .to(slide01_frame4_anim15, .5, {opacity: 1,left: 150,top: 311,delay: 6}, 'startrgt')
        .to(slide01_frame4_anim16, .5, {opacity: 1,left: 16,top: 260,delay: 7}, 'startrgt')
        .to(slide01_frame4_anim17, .5, {opacity: 1,left: -10,top: 164,delay: 8}, 'startrgt')
        .to(slide01_frame4_anim18, .5, {opacity: 1,left: 26,top: 71,delay: 9}, 'startrgt');		
		t2.timeScale(2);
		//mySlide14 = 1;
		
	}
}
mySlide11 = 0;

function Fn_Slide11() {
	
	if(mySlide11==1){
		slide11.restart();	
		
		
	}else{
		slide11.to(slide01_frame1_anim00, .5, {opacity: 1}, 'slide11')
		slide11.to(slide01_frame1_anim01, .5, {width:78}, 'slide11a')
		slide11.to(slide01_frame1_anim02, .5, {width:78}, 'slide11b')
		slide11.to(slide01_frame1_anim03, .5, {width:78}, 'slide11c')
		slide11.to(slide01_frame1_anim04, .5, {width:78}, 'slide11d')
		slide11.to(slide01_frame1_anim05, .5, {width:78}, 'slide11e')
		slide11.to(slide01_frame1_anim06, .5, {width:78}, 'slide11f')
	
		slide11.to(slide01_frame1_anim07, .5, {opacity: 1,left:-160}, 'slide11a')
		slide11.to(slide01_frame1_anim08, .5, {opacity: 1,left:-160}, 'slide11b')
		slide11.to(slide01_frame1_anim09, .5, {opacity: 1,left:140}, 'slide11c')
		slide11.to(slide01_frame1_anim10, .5, {opacity: 1,left:-150}, 'slide11d')
		slide11.to(slide01_frame1_anim11, .5, {opacity: 1,left:160}, 'slide11e')
		slide11.to(slide01_frame1_anim12, .5, {opacity: 1,left:135}, 'slide11f')
		slide11.timeScale(2);
		mySlide11 = 1;
		
	}
}
mySlide31 = 0;
function Fn_Slide31() {
	if(mySlide31==1){
		
	t3.restart();	
		
		
	}else{
    t3.to($(".imgslide2_2"), .2, {opacity: 1}, 'slide31')
		.to(slide03_frame1_anim00, .5, {opacity: 1}, 'slide31')
		.to(slide03_frame1_anim01, 1, {opacity: 1,delay: 1,scaleX: 1,scaleY: 1}, 'slide31')		
		.to(slide03_frame1_anim05, .5, {opacity: 1,right: 30,top: 30,delay: 2}, 'slide31')
		.to(slide03_frame1_anim10, 1, {opacity: 1,right: 0,top: 30,delay: 2}, 'slide31')	
		.to(slide03_frame1_anim03, .5, {opacity: 1,left: 320,top: 190,delay: 3}, 'slide31')
		.to(slide03_frame1_anim08, 1, {opacity: 1,right: 0,top: 200,delay: 3}, 'slide31')	
		.to(slide03_frame1_anim02, .5, {opacity: 1,left: 150,bottom: -30,delay: 4}, 'slide31')
		.to(slide03_frame1_anim07, 1, {opacity: 1,top: 387,delay: 4}, 'slide31')	
		.to(slide03_frame1_anim04, .5, {opacity: 1,left: -20,top: 190,delay: 5}, 'slide31')
		.to(slide03_frame1_anim09, 1, {opacity: 1,left: 0,top: 190,delay: 5}, 'slide31')	
		.to(slide03_frame1_anim06, .5, {opacity: 1,left: 30,top: 30,delay: 6}, 'slide31')
		.to(slide03_frame1_anim11, 1, {opacity: 1,left: 0,top: 30,delay: 6}, 'slide31');
		
		t3.timeScale(2);
		mySlide31 = 1;
		
	}
}
mySlide32 = 0;
function Fn_Slide32() {
	if(mySlide32==1){
		
		t4.restart();
		
		
	}else{
	var scrwidth = screen.width;
	if(scrwidth <1500){
    	t4.to(slide03_frame2_anim00, .5, {opacity: 1}, 'slide32')
        .to(slide03_frame2_anim01, 1, {opacity: 1,delay: 1,scaleX: 1,scaleY: 1}, 'slide32')
    	.to(slide03_frame2_anim02, 1, {css:{marginLeft:9+"%", opacity: 1},delay: 2}, 'slide32')
        .to(slide03_frame2_anim03, 1, {css:{marginLeft:9+"%", opacity: 1},delay: 3}, 'slide32')
        .to(slide03_frame2_anim04, 1, {css:{marginLeft:9+"%", opacity: 1},delay: 4}, 'slide32')
    	.to(slide03_frame2_anim05, 1, {css:{marginRight:9+"%", opacity: 1},delay: 5}, 'slide32')
        .to(slide03_frame2_anim06, 1, {css:{marginRight:9+"%", opacity: 1},delay: 6}, 'slide32')
        .to(slide03_frame2_anim07, 1, {css:{marginRight:9+"%", opacity: 1},delay: 7}, 'slide32')
   	 	.to(slide03_frame2_anim08, 1, {css:{marginTop:0, opacity: 1},delay: 8}, 'slide32')
		
		t4.timeScale(2);
		
		}else{
			
		t4.to(slide03_frame2_anim00, .5, {opacity: 1}, 'slide32')
        .to(slide03_frame2_anim01, 1, {opacity: 1,delay: 1,scaleX: 1,scaleY: 1}, 'slide32')
    	.to(slide03_frame2_anim02, 1, {css:{marginLeft:17+"%", opacity: 1},delay: 2}, 'slide32')
        .to(slide03_frame2_anim03, 1, {css:{marginLeft:17+"%", opacity: 1},delay: 3}, 'slide32')
        .to(slide03_frame2_anim04, 1, {css:{marginLeft:17+"%", opacity: 1},delay: 4}, 'slide32')
    	.to(slide03_frame2_anim05, 1, {css:{marginRight:17+"%", opacity: 1},delay: 5}, 'slide32')
        .to(slide03_frame2_anim06, 1, {css:{marginRight:17+"%", opacity: 1},delay: 6}, 'slide32')
        .to(slide03_frame2_anim07, 1, {css:{marginRight:17+"%", opacity: 1},delay: 7}, 'slide32')
   	 	.to(slide03_frame2_anim08, 1, {css:{marginTop:0, opacity: 1},delay: 8}, 'slide32')
		
		t4.timeScale(2);
		}
		mySlide32 = 1;
		
	}
}
mySlide41 = 0;
function Fn_Slide41() {
	//alert("function fire")
	if(mySlide41==1){
	t41.restart();	

	}else{
		
    t41.to(slide04_frame1_anim01, 1, {opacity: 1}, 'slide41')
        .to(slide04_frame1_anim02, 1, {opacity: 1,delay: 1}, 'slide41')
        .to(slide04_frame1_anim04, 1, {opacity: 1,left: 80,top: 10,delay: 2}, 'slide41')
        .to(slide04_frame1_anim05, 1, {opacity: 1,left: 260,top: 10,delay: 2}, 'slide41')
        .to(slide04_frame1_anim06, 1, {opacity: 1,left: 0,top: 185,delay: 2}, 'slide41')
        .to(slide04_frame1_anim07, 1, {opacity: 1,left: 170,top: 185,delay: 2}, 'slide41')
        .to(slide04_frame1_anim08, 1, {opacity: 1,left: 340,top: 185,delay: 2}, 'slide41')
        .to(slide04_frame1_anim00, 1, {opacity: 1,delay: 3}, 'slide41')
        .to(slide04_frame1_anim03, 1, {opacity: 1,delay: 4}, 'slide41');
		t41.timeScale(2);
		mySlide41 = 1;
		
	}
}
mySlide42 = 0;
function Fn_Slide42() {
	if(mySlide42==1){
		
	t5.restart();	
		
		
	}else{

    t5.to(slide04_frame2_anim01, 1, {opacity: 1}, 'slide42')
        .to(slide04_frame2_anim02, 1, {opacity: 1,delay: 1}, 'slide42')
        .to(slide04_frame2_anim00, .5, {opacity: 1,delay: 2}, 'slide42')
        .to(slide04_frame2_anim03, 1, {opacity: 1,delay: 3}, 'slide42')
    	.to(slide04_frame2_anim06, 1, {opacity: 1,delay: 4}, 'slide42')
        .to(slide04_frame2_anim10, 1, {opacity: 1,delay: 5}, 'slide42')
    	.to(slide04_frame2_anim07, 1, {opacity: 1,delay: 6}, 'slide42')
        .to(slide04_frame2_anim11, 1, {opacity: 1,delay: 7}, 'slide42')
    	.to(slide04_frame2_anim05, 1, {opacity: 1,delay: 8}, 'slide42')
        .to(slide04_frame2_anim09, 1, {opacity: 1,delay: 9}, 'slide42')
    	.to(slide04_frame2_anim04, 1, {opacity: 1,delay: 10}, 'slide42')
        .to(slide04_frame2_anim08, 1, {opacity: 1,delay: 11}, 'slide42')
		.to(slide04_frame2_anim12, 1, {opacity: 1,delay: 12}, 'slide42');
		t5.timeScale(2);
		mySlide42 = 1;
	}
}
mySlide421 = 0;
function Fn_Slide421() {
	if(mySlide421==1){
		
	t421.restart();	
		
		
	}else{

    t421.to(slide04_frame21_anim01, 1, {opacity: 1}, 'slide421')
        .to(slide04_frame21_anim02, 1, {opacity: 1,delay: 1}, 'slide421')
        .to(slide04_frame21_anim00, .5, {opacity: 1,delay: 2}, 'slide421')
        .to(slide04_frame21_anim03, 1, {opacity: 1,delay: 3}, 'slide421')
    	.to(slide04_frame21_anim06, 1, {opacity: 1,delay: 4}, 'slide421')
        .to(slide04_frame21_anim10, 1, {opacity: 1,delay: 5}, 'slide421')
    	.to(slide04_frame21_anim07, 1, {opacity: 1,delay: 6}, 'slide421')
        .to(slide04_frame21_anim11, 1, {opacity: 1,delay: 7}, 'slide421')
    	.to(slide04_frame21_anim05, 1, {opacity: 1,delay: 8}, 'slide421')
        .to(slide04_frame21_anim09, 1, {opacity: 1,delay: 9}, 'slide421')
    	.to(slide04_frame21_anim04, 1, {opacity: 1,delay: 10}, 'slide421')
        .to(slide04_frame21_anim08, 1, {opacity: 1,delay: 11}, 'slide421')
		.to(slide04_frame21_anim12, 1, {opacity: 1,delay: 12}, 'slide421');
		t421.timeScale(2);
		mySlide421 = 1;
	}
}
mySlide43 = 0;
function Fn_Slide43() {
	if(mySlide43==1){
		
	t6.restart();	
		
		
	}else{

    t6.to(slide04_frame3_anim00, .5, {opacity: 1}, 'slide43')
        .to(slide04_frame3_anim01, 1, {opacity: 1,top: -10,delay: 1}, 'slide43')
        .to(slide04_frame3_anim02, 1, {opacity: 1,left: 265,top: -40,delay: 2}, 'slide43')
        .to(slide04_frame3_anim03, 1, {opacity: 1,left: 336,top: 20,delay: 2}, 'slide43')
        .to(slide04_frame3_anim04, 1, {opacity: 1,left: 350,top: 110,delay: 2}, 'slide43')
        .to(slide04_frame3_anim05, 1, {opacity: 1,left: 312,top: 170,delay: 2}, 'slide43')
        .to(slide04_frame3_anim06, 1, {opacity: 1,left: 135,top: 170,delay: 2}, 'slide43')
        .to(slide04_frame3_anim07, 1, {opacity: 1,left: 100,top: 100,delay: 2}, 'slide43')
        .to(slide04_frame3_anim08, 1, {opacity: 1,left: 115,top: 20,delay: 2}, 'slide43')
        .to(slide04_frame3_anim09, 1, {opacity: 1,left: 175,top: -36,delay: 2}, 'slide43')
   		.to(slide04_frame3_anim10, 1, {opacity: 1,left: 255,top: -105,delay: 3}, 'slide43')
        .to(slide04_frame3_anim11, 1, {opacity: 1,left: 356,top: -15,delay: 4}, 'slide43')
        .to(slide04_frame3_anim12, 1, {opacity: 1,left: 380,top: 100,delay: 5}, 'slide43')
        .to(slide04_frame3_anim13, 1, {opacity: 1,left: 322,top: 190,delay: 6}, 'slide43')
        .to(slide04_frame3_anim14, 1, {opacity: 1,left: -7,top: 190,delay: 7}, 'slide43')
        .to(slide04_frame3_anim15, 1, {opacity: 1,left: -55,top: 100,delay: 8}, 'slide43')
        .to(slide04_frame3_anim16, 1, {opacity: 1,left: -60,top: -10,delay: 9}, 'slide43')
        .to(slide04_frame3_anim17, 1, {opacity: 1,left: 50,top: -100,delay: 10}, 'slide43')
        .to(slide04_frame3_anim18, 1, {opacity: 1,delay: 11}, 'slide43');
		t6.timeScale(2);
		mySlide43 = 1;
	}
}

mySlide44 = 0;
function Fn_Slide44() {
	if(mySlide44==1){
		
	t7.restart();	
		
		
	}else{
    t7.to(slide04_frame4_anim00, 1, {opacity: 1,delay: 1}, 'slide44')
        .to(slide04_frame4_anim01, 1, {opacity: 1,delay: 2}, 'slide44')
        .to(slide04_frame4_anim02, 1, {opacity: 1,delay: 3}, 'slide44')
        .to(slide04_frame4_anim03, 1, {opacity: 1,delay: 4}, 'slide44')
        .to(slide04_frame4_anim04, 1, {opacity: 1,delay: 5}, 'slide44')
        .to(slide04_frame4_anim05, 1, {opacity: 1,delay: 2}, 'slide44')
        .to(slide04_frame4_anim06, 1, {opacity: 1,delay: 3}, 'slide44')
        .to(slide04_frame4_anim07, 1, {opacity: 1,delay: 4}, 'slide44')
        .to(slide04_frame4_anim08, 1, {opacity: 1,delay: 5}, 'slide44')
        .to(slide04_frame4_anim09, 1, {opacity: 1,delay: 6}, 'slide44');
		t7.timeScale(2);
		mySlide44=1;
	}
}

mySlide51 = 0;
function Fn_Slide51() {
	if(mySlide51==1){
		
	t8.restart();	
		
		
	}else{
    t8.to(slide05_frame1_anim00, 1, {opacity: 1}, 'slide51')
        .to(slide05_frame1_anim01, 1, {opacity: 1,delay: 1}, 'slide51')
        .to(slide05_frame1_anim02, 1, {opacity: 1,delay: 2}, 'slide51')
        .to(slide05_frame1_anim03, 1, {opacity: 1,delay: 3}, 'slide51')
        .to(slide05_frame1_anim04, 1, {opacity: 1,delay: 4}, 'slide51')
        .to(slide05_frame1_anim05, 1, {opacity: 1,delay: 5}, 'slide51')
        .to(slide05_frame1_anim06, 1, {opacity: 1,delay: 6}, 'slide51')
        .to(slide05_frame1_anim07, 1, {opacity: 1,delay: 1}, 'slide51')
        .to(slide05_frame1_anim08, 1, {opacity: 1,delay: 2}, 'slide51')
        .to(slide05_frame1_anim09, 1, {opacity: 1,delay: 3}, 'slide51')
        .to(slide05_frame1_anim10, 1, {opacity: 1,delay: 4}, 'slide51')
        .to(slide05_frame1_anim11, 1, {opacity: 1,delay: 5}, 'slide51')
        .to(slide05_frame1_anim12, 1, {opacity: 1,delay: 6}, 'slide51')
        .to(slide05_frame1_anim13, 1, {opacity: 1,delay: 7}, 'slide51');
		t8.timeScale(2);
		mySlide51=1;
	}
}

mySlide52 = 0;
function Fn_Slide52() {
	if(mySlide52==1){
		
	t9.restart();	
		
		
	}else{
    t9.to(slide05_frame2_anim00, 1, {opacity: 1}, 'slide52')
        .to(slide05_frame2_anim01, 1, {opacity: 1,delay: 1}, 'slide52')
    	.to(slide05_frame2_anim02, 1, {opacity: 1,left: 50,top: -60,delay: 2}, 'slide52')
        .to(slide05_frame2_anim03, 1, {opacity: 1,left: 200,top: 17,delay: 2}, 'slide52')
        .to(slide05_frame2_anim04, 1, {opacity: 1,left: 140,top: 166,delay: 2}, 'slide52')
        .to(slide05_frame2_anim05, 1, {opacity: 1,left: -40,top: 180,delay: 2}, 'slide52')
        .to(slide05_frame2_anim06, 1, {opacity: 1,left: -90,top: 24,delay: 2}, 'slide52')
        .to(slide05_frame2_anim07, 1, {opacity: 1,left: 60,top: -50,delay: 2}, 'slide52')
        .to(slide05_frame2_anim08, 1, {opacity: 1,left: 210,top: 27,delay: 3}, 'slide52')
        .to(slide05_frame2_anim09, 1, {opacity: 1,left: 150,top: 176,delay: 4}, 'slide52')
        .to(slide05_frame2_anim10, 1, {opacity: 1,left: -30,top: 190,delay: 5}, 'slide52')
        .to(slide05_frame2_anim11, 1, {opacity: 1,left: -80,top: 34,delay: 6}, 'slide52')
        .to(slide05_frame2_anim12, 1, {opacity: 1,delay: 7}, 'slide52');
		t9.timeScale(2);
		mySlide52=1;
	}
}

mySlide53 = 0;
function Fn_Slide53() {
	if(mySlide53==1){
		
	t10.restart();	
		
		
	}else{
    t10.to(slide05_frame3_anim00, 1, {opacity: 1}, 'slide53')
        .to(slide05_frame3_anim01, 1, {opacity: 1,left: 280,top: -14,          delay: 1}, 'slide53')        
		.to(slide05_frame3_anim02, 1, {opacity: 1,left: 365,top: 112,delay: 1}, 'slide53')
        .to(slide05_frame3_anim03, 1, {opacity: 1,left: 275,top: 275,delay: 1}, 'slide53')
        .to(slide05_frame3_anim04, 1, {opacity: 1,left: 85,top: 270,delay: 1}, 'slide53')
        .to(slide05_frame3_anim05, 1, {opacity: 1,left: 45,top: 110,delay: 1}, 'slide53')
        .to(slide05_frame3_anim06, 1, {opacity: 1,left: 82,top: -12,delay: 1}, 'slide53')
        .to(slide05_frame3_anim07, 1, {opacity: 1,delay: 2}, 'slide53');
		t10.timeScale(2);
		mySlide53=1;
	}
}

mySlide54 = 0;
function Fn_Slide54() {
	if(mySlide54==1){
		
	t11.restart();	
		
		
	}else{
    t11.to(slide05_frame4_anim00, .5, {opacity: 1}, 'slide54')
        .to(slide05_frame4_anim01, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame4_anim02, 1, {opacity: 1,delay: 2}, 'slide54')
        .to(slide05_frame4_anim03, 1, {opacity: 1,delay: 3}, 'slide54')
        .to(slide05_frame4_anim04, 1, {opacity: 1,delay: 4}, 'slide54')
        .to(slide05_frame4_anim05, 1, {opacity: 1,delay: 5}, 'slide54')
        .to(slide05_frame4_anim06, 1, {opacity: 1,delay: 6}, 'slide54')
        .to(slide05_frame4_anim07, 1, {opacity: 1,delay: 7}, 'slide54')
        .to(slide05_frame4_anim08, 1, {opacity: 1,delay: 8}, 'slide54')

    .to(slide05_frame4_anim09, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame4_anim10, 1, {opacity: 1,delay: 2}, 'slide54')
        .to(slide05_frame4_anim11, 1, {opacity: 1,delay: 3}, 'slide54')
        .to(slide05_frame4_anim12, 1, {opacity: 1,delay: 4}, 'slide54')
        .to(slide05_frame4_anim13, 1, {opacity: 1,delay: 5}, 'slide54')
        .to(slide05_frame4_anim14, 1, {opacity: 1,delay: 6}, 'slide54')
        .to(slide05_frame4_anim15, 1, {opacity: 1,delay: 7}, 'slide54')
        .to(slide05_frame4_anim16, 1, {opacity: 1,delay: 8}, 'slide54')

    .to(slide05_frame4_anim17, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame4_anim18, 1, {opacity: 1,delay: 2}, 'slide54')
        .to(slide05_frame4_anim19, 1, {opacity: 1,delay: 3}, 'slide54')
        .to(slide05_frame4_anim20, 1, {opacity: 1,delay: 4}, 'slide54')
        .to(slide05_frame4_anim21, 1, {opacity: 1,delay: 5}, 'slide54')
        .to(slide05_frame4_anim22, 1, {opacity: 1,delay: 6}, 'slide54')
        .to(slide05_frame4_anim23, 1, {opacity: 1,delay: 7}, 'slide54')
        .to(slide05_frame4_anim24, 1, {opacity: 1,delay: 8}, 'slide54');
		t11.timeScale(2);
		mySlide54=1;
	}
}

mySlide55 = 0;
function Fn_Slide55() {
	if(mySlide55==1){
		
	t12.restart();	
		
		
	}else{
    t12.to(slide05_frame5_anim00, 1, {opacity: 1}, 'slide54')
        .to(slide05_frame5_anim01, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame5_anim02, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame5_anim03, 1, {opacity: 1,delay: 2}, 'slide54')
        .to(slide05_frame5_anim04, 1, {opacity: 1,delay: 3}, 'slide54');
		t12.timeScale(2);
		mySlide55=1;
	}
}

mySlide56 = 0;
function Fn_Slide56() {
	if(mySlide56==1){
		
	t13.restart();	
		
		
	}else{
    t13.to(slide05_frame6_anim00, .5, {opacity: 1}, 'slide54')
        .to(slide05_frame6_anim01, 1, {opacity: 1,delay: 1}, 'slide54')
        .to(slide05_frame6_anim02, 1, {opacity: 1,delay: 2}, 'slide54')
        .to(slide05_frame6_anim03, 1, {opacity: 1,left: 10 + "%",delay: 3}, 'slide54');
		t13.timeScale(2);
		mySlide56=1;
	}
}

mySlide71 = 0;
function Fn_Slide71() {
	if(mySlide71==1){
		
	t71.restart();	
		
		
	}else{
    t71.to(slide07_frame1_anim00, 1, {opacity: 1,top:50}, 'slide71')
        .to(slide07_frame1_anim01, 1, {opacity: 1,top:105,delay: 1}, 'slide71')
        .to(slide07_frame1_anim02, 1, {opacity: 1,top:128,delay: 2}, 'slide71')
		.to(slide07_frame1_anim03, 1, {opacity: 1,top:186,delay: 3}, 'slide71')
        .to(slide07_frame1_anim04, 1, {opacity: 1,top:208,delay: 4}, 'slide71')
		.to(slide07_frame1_anim05, 1, {opacity: 1,top:284,delay: 5}, 'slide71')
        .to(slide07_frame1_anim06, 1, {opacity: 1,top:307,delay: 6}, 'slide71')
		
		.to(slide07_frame1_anim08, 1, {opacity: 1,top:50}, 'slide71')
        .to(slide07_frame1_anim07, 1, {opacity: 1,top:108,delay: 1}, 'slide71')
		.to(slide07_frame1_anim10, 1, {opacity: 1,top:126,delay: 2}, 'slide71')
        .to(slide07_frame1_anim09, 1, {opacity: 1,top:205,delay: 3}, 'slide71')
		.to(slide07_frame1_anim12, 1, {opacity: 1,top:228,delay: 4}, 'slide71')
		.to(slide07_frame1_anim11, 1, {opacity: 1,top:324,delay: 5}, 'slide71')
		.to(slide07_frame1_anim13, 1, {opacity: 1,top:347,delay: 6}, 'slide71')
		
		t71.timeScale(2);
		mySlide71=1;
	}
}

function Fn_closeThyroidAssist() {
    TweenLite.to(ThyroidAssist, 1, {opacity: 1,top: -animateheight});
    TweenLite.to(Popup_AssistImg, 1, {opacity: 0});
	MouseTrueFPage1();
	mymenurollover = 1;
}

function fn_showvideos(myvar) {
	MouseFalseFPage1();
    if (myvar == 0) {
        $.fancybox("#videothyroid");
        $("#videoslide1frame").attr("src", "https://www.youtube.com/embed/iNrUpBwU3q0?rel=0&autoplay=1");
    } else if (myvar == 1) {
        $.fancybox("#videojuhi");
		videoPlayer.play();
    }
}

function fn_hidevideos(myvar) {
    $.fancybox.close();
	MouseTrueFPage1();
	if (myvar == 0) {
        $("#videoslide1frame").attr("src", " ");
    } else if (myvar == 1) {
        
    }
}

function fn_assistpopup(myvar) {
	if (myvar == 0) {		
        var r = confirm("NOW YOU ARE BEING DIRECTED TO THYROCARE WEBSITE. \n\nAbbott India Limited is not responsible, and provides no warranty whatsoever, for the accuracy, effectiveness, timeliness and suitability of any information or content obtained from third parties, including any hyperlinks to or from third-party sites. Except as otherwise provided on this Web site, Abbott India Limited will not edit, censor or otherwise control any content provided by third parties on any bulletin board, chat room or other similar forums posted on its Web site. Such information should, therefore, be considered as suspect and is not endorsed by Abbott India Limited.It is only in public interest that this laboratory has been provided. Abbott India Limited is not biased towards any laboratory mentioned on this site. Through this link, Abbott India is not promoting any laboratory & is open to partnerships with other laboratories. If any laboratory chain in India is interested to be a partner in this good cause & is ready to offer discounted tests of thyroid dysfunction to the public, they can write to us at thyrohealthindia@abbott.com. Abbott India will not be held responsible for change in address or contact details of any of the Laboratories & their services. The user is requested to verify these details at the time of using the services of the respective laboratories.\n\nClick 'OK' to proceed.");
        if (r == true) {
           window.open("https://www.thyrocare.com/wellness/Emailer/Abbott_Index.html");
        }
    } else if (myvar == 1) {
        $.fancybox("#calltobooktest");
		MouseFalseFPage1();
    } else if (myvar == 2) {
        $.fancybox("#smstobooktest");
		MouseFalseFPage1();
    } else if (myvar == 3) {
        $.fancybox("#self_assessment");		
		$('.ChkBox').removeAttr('checked');	
		mycheckboxcount = 0;	
		$('#SelfAsstCont').css("display","block");
		$('#SelfAsstResult').css("display","none");
		$('.txtAge').html("");
		MouseFalseFPage1();
    } else if (myvar == 4) {
        $.fancybox("#downloadapp");
		MouseFalseFPage1();
     } else if (myvar == 5) {
        $.fancybox("#patientedu");
		MouseFalseFPage1();
    }else if (myvar == 6) {
        $.fancybox("#find_thyroid_clinic");
		MouseFalseFPage1();
    } else if (myvar == 7) {
		var r = confirm("NOW YOU ARE BEING DIRECTED TO THYROCARE WEBSITE. \n\nAbbott India Limited is not responsible, and provides no warranty whatsoever, for the accuracy, effectiveness, timeliness and suitability of any information or content obtained from third parties, including any hyperlinks to or from third-party sites. Except as otherwise provided on this Web site, Abbott India Limited will not edit, censor or otherwise control any content provided by third parties on any bulletin board, chat room or other similar forums posted on its Web site. Such information should, therefore, be considered as suspect and is not endorsed by Abbott India Limited.It is only in public interest that this laboratory has been provided. Abbott India Limited is not biased towards any laboratory mentioned on this site. Through this link, Abbott India is not promoting any laboratory & is open to partnerships with other laboratories. If any laboratory chain in India is interested to be a partner in this good cause & is ready to offer discounted tests of thyroid dysfunction to the public, they can write to us at thyrohealthindia@abbott.com. Abbott India will not be held responsible for change in address or contact details of any of the Laboratories & their services. The user is requested to verify these details at the time of using the services of the respective laboratories.\n\nClick 'OK' to proceed.");
        if (r == true) {
            window.open("https://www.thyrocare.com/wellness/Nearest_service_provider.aspx?val_redirect=ABBOTT");
        }
    } else if (myvar == 8) {
        $.fancybox("#find_chemist");
		MouseFalseFPage1();
    }
}
function fn_assistpopupclose(myvar) {
	MouseTrueFPage1();
    if (myvar == 0) {
        $.fancybox.close();
    } else if (myvar == 6) {
        $.fancybox.close();
        $('#labscrollbar').css("visibility", "hidden");
    } else if (myvar == 8) {
        $.fancybox.close();
        $("#FindClinic").css('display', 'block');
        $("#FindDoctor").css('display', 'none');
        $("#liFindClinic").addClass('current');
        $("#liFindDoc").removeClass('current');
    } 
}

function Fn_DownloadApp(myvar) {
	if(myvar == 0){
			var r = confirm("NOW YOU ARE BEING DIRECTED TO GOOGLE PLAY WEBSITE.\nClick 'OK' to proceed.");
		 if (r == true) {
			window.open("http://goo.gl/7DhYng");
		 }
	}else if(myvar == 1){
		var r = confirm("NOW YOU ARE BEING DIRECTED TO APPLE STORE WEBSITE.\nClick 'OK' to proceed.");
		 if (r == true) {			
			window.open("https://itunes.apple.com/us/app/thyro-app/id903920061?mt=8");
		 }
	}
}

function Fn_ContactUs(){
	MouseFalseFPage1();
	$.fancybox("#contactus");
}
function Fn_Feedback(){
	MouseFalseFPage1();
	$.fancybox("#feedback");
}
function Fn_Disclaimer(){
	MouseFalseFPage1();
	$.fancybox("#disclaimer");
}
function Fn_LegalNotice(){
	MouseFalseFPage1();
	$.fancybox("#legalnotice");
}
function Fn_SiteMap(){
	MouseFalseFPage1();
	$.fancybox("#sitemap");
}
function Fn_PrivacyPolicy(){
	MouseFalseFPage1();
	$.fancybox("#privacypolicy");
}
function Fn_AbbottIndia() {
		var r = confirm("Now you are being directed to Abbott India website.\nClick 'OK' to proceed.");
		 if (r == true) {
			window.open("http://www.abbott.co.in/");
		 }
}
function Fn_ThyroidIndia() {
		var r = confirm("Now you are being directed to Abbott India website.\nClick 'OK' to proceed.");
		 if (r == true) {
			window.open("http://www.abbott.co.in/");
		 }
}
function Fn_References() {
	MouseFalseFPage1();
	$.fancybox("#reference");	
}
function fn_closepopup(){
	$.fancybox.close();
	MouseTrueFPage1();
}
function fn_reference(myvar) {
	MouseFalseFPage1();
	fn_reffromshared(myvar);
	$.fancybox("#references1");
}
