from django.conf.urls import url

from brahm import views

urlpatterns = [
    url(r'^$', views.girl, name='girl'),
    url(r'^article/(\d+)/', views.viewArticle, name = 'article'),
]

