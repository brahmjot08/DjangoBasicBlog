# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from brahm.models import Dreamreal
from django.shortcuts import render
import datetime

# Create your views here.

from django.http import HttpResponse


def index(request):
    return HttpResponse("Hello, world. You're at the brahm's index.")

def sum(request):
    return HttpResponse("2+3=5")

def male(request):
    return render(request, "index.html")

def hello(request):
   text = """<h1>welcome to my app !</h1>"""
   return HttpResponse(text)

def hello1(request):
    return render(request,"/home/gaurav/Videos/testing_brahm/brahm/templates/hello.html",{})

def hello3(request, number):
   text = "<h1>welcome to my app number %s!</h1>"% number
   return HttpResponse(text)

def girl(request):
    return HttpResponse("welcome girls!!")


def viewArticle(request, articleId):
   text = "Displaying article Number : %s"%articleId
   return HttpResponse(text)


def viewArticle(request, month, year):
   text = "Displaying articles of : %s/%s"%(year, month)
   return HttpResponse(text)

def hello4(request):
   today = datetime.datetime.now().date()
   daysofweek=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
   return render(request, "hello1.html", {"today" : today,"days_of_week" : daysofweek})

def crudops(request):
    dreamreal=Dreamreal(website="www.anand.com",mail="brahmjot.webtunix@gmail.com",name="Brahmjot",phonenumber="9780407805")
    dreamreal.save()
    objects=Dreamreal.objects.all()
    res = 'Printing all Dreamreal entries in the DB : <br>'
    for elt in objects:
        res += elt.name + "<br>"
        # Read a specific entry:
    sorex = Dreamreal.objects.get(name="sorex")
    res += 'Printing One entry <br>'
    res += sorex.name

    # Delete an entry
    res += '<br> Deleting an entry <br>'
    sorex.delete()

    # Update
    dreamreal = Dreamreal(
        website="www.polo.com", mail="sorex@polo.com",
        name="sorex", phonenumber="002376970"
    )

    dreamreal.save()
    res += 'Updating entry<br>'

    dreamreal = Dreamreal.objects.get(name='sorex')
    dreamreal.name = 'thierry'
    dreamreal.save()

    return HttpResponse(res)
