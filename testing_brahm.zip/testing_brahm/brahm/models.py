# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Dreamreal(models.Model):
    website = models.CharField(max_length=50)
    mail = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    phonenumber = models.IntegerField()

    class Meta:
        db_table = "Employee"

# Create your models here.
